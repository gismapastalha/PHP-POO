<?php
	try {
		//comprobar que nos llega un fichero

		//recuperar los parámetros que necesitamos del fichero: tmp_name, name y size
		
		//validar tamaño del archivo
		
		//mover el archivo de la carpeta temporal a la carpeta definitiva en el servidor
			
		//confeccionar el mensaje de respuesta
	} catch (Exception $e) {
		//confeccionar el mensaje de respuesta en caso de error
	}
	
	//enviar la respuesta ajax
?>