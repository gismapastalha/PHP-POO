<?php
	//clase genérica Cliente

		//atributos

		//constructor

		//getters y setters

		//otros métodos

	// ------------------------------------------

	//subclase ClienteNacional

		//atributo específico

		//constructor

		//getter y setter

		//otros métodos

	// ------------------------------------------

	//subclase ClienteExtranjero

		//atributo específico

		//constructor

		//getter y setter

		//otros métodos

	// ------------------------------------------

	//instanciar un cliente Nacional y mostrar datos

	//instanciar un cliente Extranjero y mostrar datos