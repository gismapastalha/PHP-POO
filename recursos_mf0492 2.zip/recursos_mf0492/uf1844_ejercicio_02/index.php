<?php
	//definir una variable con la nota aleatoria

	//llamar a la función de obtención de calificación y recoger el resultado en una variable

	//definir la función 
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Funciones</title>
	<meta charset='UTF-8'>	
	<style type="text/css">
		div {text-align: center; border:1px solid grey;width: 390px;margin: auto;}
		h2 {text-align: center;}
	</style>
</head>
<body>
	<h2>Funciones</h2>
	<div>
		<span>Nota: </span>
	</div>
	<div>
		<span>Calificación: </span>
	</div>
</body>
</html>