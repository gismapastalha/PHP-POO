-- Consulta 1: Nom i cognoms de tots els usuaris ordenats per cognoms (6 registres) 


-- Consulta 2: Número total d’usuaris amb el email sense informar (2)


-- Consulta 3: Usuaris on la segona lletra del seu cognom sigui la lletra 'a' (2 registres)


-- Consulta 4: Nom i cognoms dels usuaris que han enviat comentaris. Hauria de sortir una fila per cada usuari diferent (4 registres o 7 registres sense agrupar)


-- Consulta 5: Nom i cognoms dels usuaris que no han enviat cap comentari (2 registres)


-- Consulta 6: Accedir per la taula usuaris per tal d'obtenir els comentaris que no pertanyen a cap usuari (1 registre)


-- Consulta 7: Nom, cognoms i numero de comentaris enviats per cadascú dels usuaris (4 registres)


